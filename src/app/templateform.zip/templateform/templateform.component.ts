import { Component, OnInit } from '@angular/core';
import { Subscription, Subject } from 'rxjs';
import { CommonService } from '../services/common.service'
import { AuditService } from '../services/audit.service'
import { drpplant, url, drpTemplate, drpEmployeeMaster } from '../Models/common';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { debounceTime, delay, filter, map, takeUntil, distinctUntilChanged, tap } from 'rxjs/operators';
import { AuditCodeDetail } from '../Models/models';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.css']
})
export class TemplateformComponent implements OnInit {
  msbapTitle = 'Audio Title';
msbapAudioUrl = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';   

msbapDisplayTitle = false; 
  showProgress = false;
  plantNameList: any;
  templateList: any;
  employeeList: any;
  plantNameListSub: Subscription;
  templateListSub: Subscription;
  startAudit: Subscription;
  protected _onDestroy = new Subject<void>();
  public FileteredEmployeeData: any;
  public FileteredPlantQualityHeadCtrl: any;
  public DropDownPlantHeadCtrl: FormControl = new FormControl();
  public DropDownPlantQualityHeadCtrl: FormControl = new FormControl();
  constructor(
    private CommonService: CommonService,
    private AuditService: AuditService,
    private fb: FormBuilder,
    private Router_:Router) { }
  sub: Subscription;
  sub_: Subscription;
  saveData: Subscription;
  form: FormGroup
  ngOnInit() {
this.showProgress=true;
    console.log(drpplant);
    this.bindFormData();
  }

  bindFormData() {
    this.bindForm()
    this.bindDropDownEmp();
    this.bindplants();
    this.bindtemplate();
    this.bindEmployeeCode();
  }
  bindForm() {
    this.form = this.fb.group({
      Plant: new FormControl(null, Validators.required),
      qmsCert: new FormControl(null, Validators.required),
      plantHead: new FormControl(null, Validators.required),
      plantQualityHead: new FormControl(null, Validators.required),
      template: new FormControl(null, Validators.required),
      RevisionDate: new FormControl(null, Validators.required)
    })
  }
  bindDropDownEmp() {
    this.sub = this.DropDownPlantHeadCtrl.valueChanges
      .pipe(
        takeUntil(this._onDestroy),
        debounceTime(200),
        distinctUntilChanged(),
        filter(search => !!search),
        map(search => this.CommonService.getEmployee(search))
      ).subscribe(res => {
        this.FileteredEmployeeData = res;
      });
    this.sub_ = this.DropDownPlantQualityHeadCtrl.valueChanges
      .pipe(
        takeUntil(this._onDestroy),
        debounceTime(200),
        distinctUntilChanged(),
        filter(search => !!search),
        map(search => this.CommonService.getEmployee(search))
      ).subscribe(res => {
        
        this.FileteredPlantQualityHeadCtrl = res;
      });



  }

  formateData(search) {
    drpEmployeeMaster.Search = search
    return drpEmployeeMaster
  }
  bindplants() {
    this.plantNameListSub = this.CommonService.getPlant(drpplant).subscribe(
      data => {
        this.showProgress=false;
        if (data.ResponseCode == "00") {
          this.plantNameList = data.ResponseData
        }
      }
    )
  }
  bindtemplate() {

    this.templateListSub = this.CommonService.getTemplate(drpTemplate).subscribe(
      data => {
        this.showProgress=false;
        if (data.ResponseCode == '00') {
          this.templateList = data.ResponseData
        }
      }
    )
  }
  bindEmployeeCode() {

  }
  submit() {
    this.showProgress=true;
    console.log(this.form.value);
    const formData: AuditCodeDetail = this.getValueInformate(this.form.value);
    this.saveData = this.AuditService.startAudit(formData).subscribe(
      data=>{
        this.showProgress=false;
        console.log('log');
        console.log(data);
        if(data.ResponseCode =="00")
        {
          localStorage.setItem('template', JSON.stringify(data.ResponseData) );
          this.Router_.navigate(['quiz'])
        }
        else{
          Swal.fire('Oops...', 'Something Went Wrong!', 'error')
        }
      }
    );
  }

  getValueInformate(formvalue: any): AuditCodeDetail {
    const data: AuditCodeDetail = {} as AuditCodeDetail;
    data.s_TemplateCode = formvalue.template;
    data.s_PlantCode = formvalue.Plant;
    data.s_PlantHead = formvalue.plantHead;
    data.s_PlantQualityHead = formvalue.plantQualityHead;
    data.d_AuditDate=formvalue.qmsCert
    data.ActionType = "Select";
    data.s_CreatedBy =this.CommonService.getEmployeeCode();
    return data;
  }
}
