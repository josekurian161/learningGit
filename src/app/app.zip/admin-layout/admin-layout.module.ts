import { NgModule  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AdminLayoutRoutes } from './admin-layout-routing.module';
import { QuizComponent } from '../quiz/quiz.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { FlexLayoutModule } from "@angular/flex-layout";
import {LayoutModule} from '@angular/cdk/layout';
import {MatCardModule} from '@angular/material/card';
import {MatDialogModule} from '@angular/material/dialog';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatButtonModule, MatCheckboxModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatListModule, MatSelectModule, MatInputModule, MatRadioModule} from '@angular/material';
@NgModule({

  imports: [
    CommonModule,
    FlexLayoutModule,
    RouterModule.forChild(AdminLayoutRoutes),
     MatButtonModule,
    MatCheckboxModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatRadioModule
  ],
  declarations: [
    QuizComponent,
    DashboardComponent
  ]
})
export class AdminLayoutModule { }
