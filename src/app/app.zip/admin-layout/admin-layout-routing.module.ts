import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QuizComponent } from '../quiz/quiz.component';
import { DashboardComponent } from '../dashboard/dashboard.component';

export const AdminLayoutRoutes: Routes = [

  { path: 'quiz',component: QuizComponent },
  {path:'dashboard',component:DashboardComponent}
];


export class AdminLayoutRoutingModule { }
