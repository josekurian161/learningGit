import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  LoginArray:FormGroup;
  constructor(private router:Router,
    private fb:FormBuilder) { }

  ngOnInit() {
    this.LoginArray=this.fb.group(
      {
        Username:[null,Validators.required],
        Password:[null,Validators.required]
      }
    )
  }
  login_()
  {
    console.log(this.LoginArray.value);
    this.router.navigate(['dashboard'])
  }

}
