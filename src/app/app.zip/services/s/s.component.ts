import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-s',
  templateUrl: './s.component.html',
  styleUrls: ['./s.component.css']
})
export class SComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
