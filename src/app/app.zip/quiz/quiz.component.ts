import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material'; 
import { MyDialogComponent } from '../my-dialog/my-dialog.component';
import { AuditService } from '../service/audit.service';
import {TestService} from '../test/test.service'

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  constructor(private AuditService:AuditService,private TestService:TestService,public dialog: MatDialog) { }

  ngOnInit() {
    debugger;
 this.TestService.fetchData('');
// this.AuditService.fetchData('');
  }

  openDialog(): void {
    //console.log("prasad");    
    let dialogRef = this.dialog.open(MyDialogComponent, {       
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed'); 
    });
  }

}
